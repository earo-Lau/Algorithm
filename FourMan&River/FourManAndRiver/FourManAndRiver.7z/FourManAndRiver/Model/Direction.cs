﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FourManAndRiver.Model
{
    /// <summary>
    /// 方向
    /// </summary>
    public enum Direction
    {
        Left = 0,
        Right = 1
    }
}
