﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FourManAndRiver.Model
{
    /// <summary>
    /// 人
    /// </summary>
    public enum Man
    {
        Empty = 0,
        A = 1,
        B = 2,
        C = 5,
        D = 10
    }
}
